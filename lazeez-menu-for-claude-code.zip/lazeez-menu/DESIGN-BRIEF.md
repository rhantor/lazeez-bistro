# Lazeez Bistro — Menu Web Page Brief

The original PDF's text layer is unreadable (embedded fonts are not Unicode-mapped), so use the files here instead:

- `menu.json` — all 115 items (149 price points incl. variants), sections, variants and prices (spelling already corrected)
- `menu-page-1.png` — Beverage & Dessert spread + cover (reference for theme)
- `menu-page-2.png` — Arabic / Italian & Western / Malaysian / Side Dish spread

## Brand
- **Name:** Lazeez *Bistro* — "Lazeez" in a bold condensed sans (dark green), "Bistro" in an italic calligraphic script (gold)
- **Tagline:** ARABIC • MALAYSIAN • WESTERN (letter-spaced small caps)
- **Logo motif:** a hanging Arabic lantern inside a pointed Moorish arch, gold line-art

## Colour palette (sampled from the PDF)
| Role | Hex (approx.) |
|---|---|
| Deep green (headers, prices, footer band) | `#1F6B3A` |
| Darker green (page background on food pages) | `#0F3D24` |
| Gold (arch frame, accents, "Bistro" script) | `#C9A24A` |
| Cream / parchment (menu panels) | `#F3EBDD` |
| Off-white (card backgrounds) | `#FAF6EE` |
| Section-header red/orange (e.g. "Tea", "Soup") | `#B5451B` |
| Body text | `#2B2B2B` |

## Decoration
- Repeating **Islamic geometric star / lattice pattern** as a full-page background at low opacity (gold on cream, or gold on dark green).
- Each menu panel is a **cream card with a gold Moorish pointed-arch top edge** and thin gold double border.
- Section titles sit in a horizontal band (green background, gold text) — e.g. "Arabic", "Beverage & Dessert".
- Sub-section names (Soup, Salad, Tea…) in bold red-orange, uppercase-ish small headings.
- Items: number in muted green on the left, name in dark text, price right-aligned in bold green. Variants (a/b/c) indented under the item.
- Photos of dishes are placed as round/cut-out images floating beside item lists.

## Layout suggestions
- Desktop: 3-column card grid mirroring the print spread; mobile: single column with sticky section nav (Arabic / Italian & Western / Malaysian / Beverages & Dessert).
- Keep the footer line: *"Images for illustration purposes only • All prices are subject to 6% SST"*.
- Currency prefix `RM`, two decimals.

## Fonts (suggested web substitutes)
- Headings: **Bebas Neue** or **Oswald** (for "Lazeez")
- Script accent: **Great Vibes** or **Allura** (for "Bistro")
- Body: **Inter** or **Nunito Sans**
